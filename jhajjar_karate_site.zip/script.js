
console.log("Jhajjar District Karate Association Website Loaded");
